package com.example.caps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CapsApplicationTests {

	@Test
	void contextLoads() {
	}

}
